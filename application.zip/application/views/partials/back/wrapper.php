<?php
  $this->load->view('partials/back/header');
  $this->load->view('partials/back/sidebar');
  $this->load->view('partials/back/isi');
  $this->load->view('partials/back/footer');